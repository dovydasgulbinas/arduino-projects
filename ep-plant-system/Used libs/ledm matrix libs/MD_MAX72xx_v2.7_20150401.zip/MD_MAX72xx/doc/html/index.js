var index =
[
    [ "Hardware", "page_hardware.html", "page_hardware" ],
    [ "Software", "page_software.html", null ],
    [ "System Connections", "page_connect.html", null ]
];