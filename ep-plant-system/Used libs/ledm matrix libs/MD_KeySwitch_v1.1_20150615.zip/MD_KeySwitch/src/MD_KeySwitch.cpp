/*
  MD_KeySwitch.cpp - Library for user keyswitch on digital input.

  See main header file for information.
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.
 */

#include "MD_KeySwitch.h"

MD_KeySwitch::MD_KeySwitch(uint8_t pin) : 
_pin(pin), _onState(KEY_ON_STATE), _state(0)
{
	setDebounceTime(KEY_DEBOUNCE_TIME);
  setLongPressTime(KEY_LONGPRESS_TIME);
	setRepeatTime(KEY_REPEAT_TIME);
}

MD_KeySwitch::MD_KeySwitch(uint8_t pin, uint8_t onState) :
_pin(pin), _onState(onState), _state(0)
{
	setDebounceTime(KEY_DEBOUNCE_TIME);
  setLongPressTime(KEY_LONGPRESS_TIME);
	setRepeatTime(KEY_REPEAT_TIME);
}

void MD_KeySwitch::begin(void)
{
	if (_onState == LOW)
		pinMode(_pin, INPUT_PULLUP);
	else
		pinMode(_pin, INPUT);	
}

MD_KeySwitch::keyResult_t MD_KeySwitch::read(void)
// return true when a transition from OFF to ON states has been detected
// or auto repeat timer has expired and the key is still on
{
	bool b = (digitalRead(_pin) == _onState);
  keyResult_t k = KS_NULL;

	switch (_state)
	{
		case 0:		// waiting for first transition
			if (b)
			{
				_state = 1;		// edge detected, initiate debounce
				_timeActive = millis();
			}
			break;
		
		case 1:		
      // Wait for debounce time to run out and ignore any key swicthing
      // that migh be going on as this may be bounce
			if ((millis() - _timeActive) < _timeDebounce)
				break;
		
			// after debounce - possible long press so move to next state
			_state = 2;
			// fall through
		
    case 2:   // press?
      // Key off before a long press registered, so it must have been a press.
      // Set the return code and go back to waiting
			if (!b)
			{
  			k = KS_PRESS;		
        _state = 0;
        break;
			}
      
      // if the switch is still on and we have not run out of longpress time, then
      // just wait for the timer to expire
			if ((millis() - _timeActive) < _timeLongPress)
        break;
  
      // time has run out, we either have a long press or are heading 
      // towards repeats    
      _state = 3;
      // fall through
      
		case 3:		// long press or auto repeat?
      // Key off before a repeat press is registered, so it must have been a long press.
      // Set the return code and go back to waiting
			if (!b)
			{
        k = KS_LONGPRESS;
				_state = 0;
        break;
			}
      // fall through but remain in this state

    case 4: // repeat?      
      // Key off before another repeat press is registered, so we have finished.
      // Go back to waiting
      if (!b)
      {
        _state = 0;
        break;
      }
      
      // if the switch is still on and we have not run out of repeat time, then
      // just wait for the timer to expire
      if ((millis() - _timeActive) < _timeRepeat)
        break;

      // we are now sure we have a repeat, set the return code and remain in this 
      // state checking for further repeats
      k = KS_PRESS;
      _state = 4;
      _timeActive = millis();	// next key repeat starts now
			break;
      
		default:  // should never be here, but this will reset just in case
			_state = 0;
			break;
	}

	return(k);
}
