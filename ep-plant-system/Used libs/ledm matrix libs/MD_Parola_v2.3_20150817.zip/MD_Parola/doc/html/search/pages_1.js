var searchData=
[
  ['new_20in_20version_202',['New in Version 2',['../page_new_v2.html',1,'index']]]
];
