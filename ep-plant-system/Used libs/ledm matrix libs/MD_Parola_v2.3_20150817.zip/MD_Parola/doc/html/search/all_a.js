var searchData=
[
  ['opening',['OPENING',['../_m_d___parola_8h.html#acf3b849a996dbbe48ca173d2b0b82edaaa7184846a5fe76e856ad7803a8fe26a6',1,'MD_Parola.h']]],
  ['opening_5fcursor',['OPENING_CURSOR',['../_m_d___parola_8h.html#acf3b849a996dbbe48ca173d2b0b82edaaaccb822639899b63879fd1c0c179d7e8',1,'MD_Parola.h']]]
];
