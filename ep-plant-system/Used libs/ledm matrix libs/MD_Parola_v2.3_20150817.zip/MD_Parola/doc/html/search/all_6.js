var searchData=
[
  ['getcharspacing',['getCharSpacing',['../class_m_d___p_zone.html#aa1e61526f637c07cb3f7e00ad8fdeea1',1,'MD_PZone::getCharSpacing()'],['../class_m_d___parola.html#a8f68dc6cf4109c00f40cd2eb6df3bfde',1,'MD_Parola::getCharSpacing(void)'],['../class_m_d___parola.html#acae7ac5d8d24280a3aeb00572c7ae789',1,'MD_Parola::getCharSpacing(uint8_t z)']]],
  ['getinvert',['getInvert',['../class_m_d___p_zone.html#a220efc8620dc7ae6292cef5421505e09',1,'MD_PZone::getInvert()'],['../class_m_d___parola.html#a3029915ed2e456a47318e3f06a05d66b',1,'MD_Parola::getInvert(void)'],['../class_m_d___parola.html#a862ad99377530902c2550a082a8629af',1,'MD_Parola::getInvert(uint8_t z)']]],
  ['getpause',['getPause',['../class_m_d___p_zone.html#a19c4b81cf5bab2d9bf6a700be478ae05',1,'MD_PZone::getPause()'],['../class_m_d___parola.html#a2e88fa0cad63e11f25fa52d1852c73c3',1,'MD_Parola::getPause(void)'],['../class_m_d___parola.html#a2d925d5a975efe0d4d9a7d45e3004caa',1,'MD_Parola::getPause(uint8_t z)']]],
  ['getscrollspacing',['getScrollSpacing',['../class_m_d___p_zone.html#aeaf3cd6d51ddd5bd76ebb75db86e2299',1,'MD_PZone::getScrollSpacing()'],['../class_m_d___parola.html#abd0d9f2cd2f84381692d5cd9b8554f6a',1,'MD_Parola::getScrollSpacing()']]],
  ['getspeed',['getSpeed',['../class_m_d___p_zone.html#a0a8521180a44fc9e197ecabd7d368d6e',1,'MD_PZone::getSpeed()'],['../class_m_d___parola.html#a62ed6b65af45aef6e6a9bbad4d431e3d',1,'MD_Parola::getSpeed(void)'],['../class_m_d___parola.html#a77f476b4ffc195aec3c357f720903e38',1,'MD_Parola::getSpeed(uint8_t z)']]],
  ['getstatus',['getStatus',['../class_m_d___p_zone.html#ade54994806ef05895edd6490dd687c41',1,'MD_PZone']]],
  ['gettextalignment',['getTextAlignment',['../class_m_d___p_zone.html#aa80f13a21ff4bc3e1102e5fed74b1466',1,'MD_PZone::getTextAlignment()'],['../class_m_d___parola.html#a7f51de612af3aad0b15de2386a599ec6',1,'MD_Parola::getTextAlignment(void)'],['../class_m_d___parola.html#a6b485b580ee8e15b7ab11a73c6cd56ff',1,'MD_Parola::getTextAlignment(uint8_t z)']]],
  ['getzoneeffect',['getZoneEffect',['../class_m_d___p_zone.html#acc15c7e3f60ad76aff46f5d6244cd9d4',1,'MD_PZone::getZoneEffect()'],['../class_m_d___parola.html#a4285e8fdba021fde5973ab63348dafd9',1,'MD_Parola::getZoneEffect()']]],
  ['getzonestatus',['getZoneStatus',['../class_m_d___parola.html#a58696a833fb399fc68ed6152931baa94',1,'MD_Parola']]],
  ['grow_5fdown',['GROW_DOWN',['../_m_d___parola_8h.html#acf3b849a996dbbe48ca173d2b0b82edaac85710279c05c270d45938f8bdb75f0a',1,'MD_Parola.h']]],
  ['grow_5fup',['GROW_UP',['../_m_d___parola_8h.html#acf3b849a996dbbe48ca173d2b0b82edaa2cf74c6adedf0505e539806cbc1ef5ac',1,'MD_Parola.h']]]
];
