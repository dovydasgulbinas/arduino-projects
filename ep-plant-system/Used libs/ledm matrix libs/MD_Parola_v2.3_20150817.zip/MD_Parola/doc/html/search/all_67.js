var searchData=
[
  ['getcharspacing',['getCharSpacing',['../class_m_d___parola.html#a8f68dc6cf4109c00f40cd2eb6df3bfde',1,'MD_Parola']]],
  ['getinvert',['getInvert',['../class_m_d___parola.html#a3029915ed2e456a47318e3f06a05d66b',1,'MD_Parola']]],
  ['getpause',['getPause',['../class_m_d___parola.html#a2e88fa0cad63e11f25fa52d1852c73c3',1,'MD_Parola']]],
  ['getspeed',['getSpeed',['../class_m_d___parola.html#a62ed6b65af45aef6e6a9bbad4d431e3d',1,'MD_Parola']]],
  ['gettextalignment',['getTextAlignment',['../class_m_d___parola.html#a7f51de612af3aad0b15de2386a599ec6',1,'MD_Parola']]]
];
