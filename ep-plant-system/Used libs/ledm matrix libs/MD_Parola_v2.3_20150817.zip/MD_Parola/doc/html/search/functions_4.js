var searchData=
[
  ['md_5fparola',['MD_Parola',['../class_m_d___parola.html#a0526bfc333412a638c3f4d10a110bc5e',1,'MD_Parola::MD_Parola(uint8_t dataPin, uint8_t clkPin, uint8_t csPin, uint8_t numDevices=1)'],['../class_m_d___parola.html#a44e6232c8b2f568538e8fc0102804885',1,'MD_Parola::MD_Parola(uint8_t csPin, uint8_t numDevices=1)']]],
  ['md_5fpzone',['MD_PZone',['../class_m_d___p_zone.html#aeb91378b5a7f1f902e12fc1f43a1be2b',1,'MD_PZone']]]
];
