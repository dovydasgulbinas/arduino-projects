var index =
[
    [ "Parola Library", "page_software.html", null ],
    [ "New in Version 2", "page_new_v2.html", null ]
];